import React, { Component } from 'react'

class App extends Component {
render() {
    return(<div>This is first definitely a React app now- updated!</div>)
  }
}
export default App
