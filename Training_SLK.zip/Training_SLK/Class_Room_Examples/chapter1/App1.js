ReactDOM.render(
           <h2>This is from App1</h2>,
            document.getElementById('container1')
        );
