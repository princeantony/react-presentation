ReactDOM.render(
           <h2>This is from App2</h2>,
            document.getElementById('container2')
        );
