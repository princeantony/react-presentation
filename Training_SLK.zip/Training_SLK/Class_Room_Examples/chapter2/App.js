import Main from 'Main'
ReactDOM.render(
           <div><h2>This is from App</h2>
           This is for main component  <App /> </div>,
            document.getElementById('container')
        );
