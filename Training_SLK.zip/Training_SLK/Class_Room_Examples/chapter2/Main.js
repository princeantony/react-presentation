class Main extends Component {
  render() {
    return <div>This is from Main Component!</div>
    
  }
}
export default Main