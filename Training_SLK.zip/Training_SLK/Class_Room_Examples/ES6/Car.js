class Car { 
                constructor(){
                    this.name = "Car"
                    this.color = "Red";
                    this.GearType = "Five";
                    this.doors ="four";
                    this.basicInfo = function (){
                        console.log("name is ",this.name);
                        console.log("my car color ",this.color);
                        console.log("my car Gear type is ",this.GearType);
                        }
                    }
            };   