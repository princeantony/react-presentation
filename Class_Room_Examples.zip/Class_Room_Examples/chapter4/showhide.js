class Toggle extends React.Component 
 {
  constructor() {
    super();
    this.state ={ 
                  show: true,
                  buttonCaption: 'Hide'
                };
  }

  doToggle(event) {
    this.setState({
      show: !this.state.show,
      buttonCaption: "Show"
    })
  }
  render() {
    return (
      <div>
        <input
          type="button"
          value={this.state.buttonCaption}
          onClick={this.doToggle.bind(this)}
        />
        <br />
        {this.state.show?<div>Here we can show dynamic content</div>:''}
      </div>
    )
  }

}