class UserDetails extends React.Component 
    {
        constructor(props) {
            super(props);
           this.state = {myUser: this.props.users[0]};
        }
    
    handleChange(event) {
        if(event.target.value)
        {
            this.setState({myUsers: this.state.myUser[0]
            })
                }
        else
            this.setState({ myUsers: this.state.myUser[1]
        })
        }
     render() {
             const {imgStyle} = this.props;
       
            return (<div> 
                
                Photo : <img src={this.state.myUser.photo} style={imgStyle} /> <br />
                First Name :   {this.state.myUser.firstName}  <br /> 
                Last Name :  {this.state.myUser.lastName}  <br />
                Email :   {this.state.myUser.userInfo.email} <br />
                Age :   {this.state.myUser.userInfo.age} <br />
                My Favorit color :   <span>{(this.state.myUser.age > 30 ? 'Red': 'Green') + ' Color'}</span> <br />
                Logo : <img src={this.state.myUser.userInfo.logo} className="logoStyle" />
            </div>);
         }
    }