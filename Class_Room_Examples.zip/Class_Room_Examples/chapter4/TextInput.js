class TextInput extends React.Component 
 {
  constructor() {
    super();
    this.state ={ inputText: 'initial text'};
  }

  handleChange(event) {
    this.setState({
      inputText: event.target.value
    })
  }
  render() {
    return (
      <div>
        <input
          type="text"
          placeholder="This is going to be text"
          value={this.state.inputText}
          onChange={this.handleChange.bind(this)}
        />
        <br />
        <div>{this.state.inputText}</div>
      </div>
    )
  }

}