function UserDetails(props)
    {
            return (<div> 
                Photo : <img src={props.user.photo} style={props.imgStyle} /> <br />
                First Name :   {props.user.firstName}  <br /> 
                Last Name :  {props.user.lastName}  <br />
                Email :   {props.user.email} <br />
                Age :   {props.user.age} <br />
                My Favorit color :   <span>{(props.user.age > 30 ? 'Red': 'Green') + ' Color'}</span> <br />
                Logo : <img src={props.user.logo} className="logoStyle" />
            </div>);
    }