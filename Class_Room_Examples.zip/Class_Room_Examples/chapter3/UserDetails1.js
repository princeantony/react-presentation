class UserDetails extends React.Component 
    {
         render() {
            return (<div> 
                Photo : <img src={this.props.user.photo} style={this.props.imgStyle} /> <br />
                First Name :   {this.props.user.firstName}  <br /> 
                Last Name :  {this.props.user.lastName}  <br />
                Email :   {this.props.user.email} <br />
                Age :   {this.props.user.age} <br />
                My Favorit color :   <span>{(this.props.user.age > 30 ? 'Red': 'Green') + ' Color'}</span> <br />
                Logo : <img src={this.props.user.logo} className="logoStyle" />
            </div>);
         }
    }