class UserDetails extends React.Component 
    {
         render() {
             const {user,imgageStyle} = this.props;
            return (<div> 
                Photo : <img src={user.photo} style={imgageStyle} /> <br />
                First Name :   {user.firstName}  <br /> 
                Last Name :  {user.lastName}  <br />
                Email :   {user.email} <br />
                Age :   {user.age} <br />
                My Favorit color :   <span>{(user.age > 30 ? 'Red': 'Green') + ' Color'}</span> <br />
                Logo : <img src={user.logo} className="logoStyle" />
            </div>);
         }
    }