ReactDOM.render(
           <h2>Welcome to React Training! This is main App</h2>,
            document.getElementById('container')
        );
