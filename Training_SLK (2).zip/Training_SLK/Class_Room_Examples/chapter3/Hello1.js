class User extends Component {
render() {
    return(<div>This is first definitely a React app now- updated!</div>)
  }
}
export default window.Hello1