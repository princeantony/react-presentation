class Container extends React.Component {
   constructor(props) {
      super(props);
		
      this.state = {
         componentName:''
      }
   };

  showChildInParent(name) {
     console.log("in showChildInParent", name);
      this.setState({componentName: name});
      //this.state.componentName = name;
   }
   render() {
     console.log("in render")
      return (
         <div>
            <Component1 showMyChild = {this.showChildInParent.bind(this)} />
            {this.state.componentName == "Comp2" ? <Component2 /> : <Component3 />}
         </div>
      );
   }
}

