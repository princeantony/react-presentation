 const element = 
                (<div>
                    <center>
                        <h1>Welcome to React ToDo App! </h1>
                    </center><hr />
                    <ToDoApp />
                </div>);
            ReactDOM.render(
            element,document.getElementById('mainContainer')
        );