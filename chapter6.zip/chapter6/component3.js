class Component3 extends React.Component {
   render() {
      return (
         <div> 
            <h3>I am from Component3</h3>
         </div>
      );
   }
}