class Component2 extends React.Component {
   render() {
      return (
         <div> 
            <h3>I am from Component2</h3>
         </div>
      );
   }
}