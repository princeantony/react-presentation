class Component1 extends React.Component {

   constructor(props) {
      super(props);
		
   };

    showChild(e) {
      e.preventDefault();
      const componentName = (this.refs.txtPlace).value;
      this.props.showMyChild(componentName);
   }
   render() {
      return (
        <form>
          <div>
              <input type = "text" ref="txtPlace" /> &nbsp;
              <button onClick = {this.showChild.bind(this)}>Show child</button>&nbsp;
              
          </div>
         </form>
      );
   }
}

