class Hello2 extends Component {
render() {
    return(<div>This is hello2 definitely a React app now- updated!</div>)
  }
}
export default window.Hello2