module.exports = {
  entry: ['./App.js'],
  output: {
    path: './dist',
    filename: 'bundle.js',
    publicPath: '/'
  }
 
}
