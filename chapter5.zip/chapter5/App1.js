class App extends React.Component {

   constructor(props) {
      super(props);
		
      this.state = {
         data: 0,
         show:true,
         iamFrom: ''
      }
   };

   setNewNumber() {
      this.setState({data: this.state.data + 1})
   }
    removeContent() {
      this.setState({show:false})
   }
    setMyplace(e) {
      const place = ReactDOM.findDOMNode(this.refs.txtPlace).value;
      this.setState({iamFrom: place});
   }
   render() {
      return (
         <div>
            <button onClick = {this.setNewNumber.bind(this)}>INCREMENT</button>&nbsp;
            
            <button onClick = {this.removeContent.bind(this)}>Remove Content Component</button>
            <input type = "text" ref="txtPlace" /> &nbsp;
            <button onClick = {this.setMyplace.bind(this)}>Show my place</button>&nbsp;
            <div>
            {this.state.show ? <Content myNumber = {this.state.data} myPlace={this.state.iamFrom}></Content> : null}
            </div>
         </div>
      );
   }
}

