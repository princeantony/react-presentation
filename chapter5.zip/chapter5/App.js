class App extends React.Component {

   constructor(props) {
      super(props);
		
      this.state = {
         data: 0,
         show:true
      }
   };

   setNewNumber() {
      this.setState({data: this.state.data + 1})
   }
    removeContent() {
      this.setState({show:false})
   }
   render() {
      return (
         <div>
            <button onClick = {this.setNewNumber.bind(this)}>INCREMENT</button>&nbsp;
            <button onClick = {this.removeContent.bind(this)}>Remove Content Component</button>
            <div>
            {this.state.show ? <Content myNumber = {this.state.data}></Content> : null}
            </div>
         </div>
      );
   }
}

