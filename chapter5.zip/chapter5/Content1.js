class Content extends React.Component {
 constructor(props) {
     super(props);
     this.state ={ 
                  state: '',
                };
       console.log('From Construnctor!')
   };
   componentWillMount() {
       
      console.log('Component WILL MOUNT!')

   }

   componentDidMount() {
      console.log('Component DID MOUNT!')
   }

   componentWillReceiveProps(newProps) {  
       this.setState({state: this.props.myPlace});  
      console.log('Component WILL RECIEVE PROPS!')
   }

   shouldComponentUpdate(newProps, newState) {
       console.log('Component SHOULD UPDATE!')
      return true;
   }

   componentWillUpdate(nextProps, nextState) {
      console.log('Component WILL UPDATE!');
   }

   componentDidUpdate(prevProps, prevState) {
      console.log('Component DID UPDATE!')
   }

   componentWillUnmount() {
      console.log('Component WILL UNMOUNT!')
   }
	
   render() {
       console.log('Inside render method!')
      return (
         <div> 
            <h3>This is from Content component {this.props.myNumber}</h3>
            <div>I am from : {this.state.state}</div>
         </div>
      );
   }
}