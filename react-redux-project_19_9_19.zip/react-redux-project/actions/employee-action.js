import {SERVICE_URL} from '../constants/app-constants';
import axios from "axios";

export function saveEmployee (newEmp) {
    return {
        type: 'EMPLOYEE-CREATED',
        myNewEmployee: newEmp
    }
};
export function removeEmployee (emp) {
    return {
        type: 'EMPLOYEE-REMOVED',
        updatedEmployee: emp
    }
};

//For a GET action for RESTFul service call
export function getExternalEmployee(){
    const url =  SERVICE_URL.GET_EXT_EMPLOYEES_URL;
    const apiExternalEmployeeRequest = axios.get(url)
    return (dispatch) => {
        return apiExternalEmployeeRequest.then(({data}) => {
            dispatch({type: 'EMPLOYEE-EXTERNAL', extenalEmployees: data})
        }).catch(error => {
            throw(error);
        });
    }
};
//For a POST action for RESTFul service call
export function saveExternalEmployee(employees) {
    const url = "post url is here";
    const apiExternalEmployeeSave = axios({
        method: 'post',
        url: url,
        data: employees
    });
        
    return (dispatch) => {
        return apiExternalEmployeeSave
        .then(({data}) => {
            dispatch({type: 'EMPLOYEE-EXTERNAL-SAVE', extenalEmployees: data})
        }).catch(error => {
            throw(error);
        });
    }
};