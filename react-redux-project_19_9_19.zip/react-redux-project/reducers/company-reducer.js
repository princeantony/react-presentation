export default function (state = null, action) {
    switch (action.type) {
        case 'TODO-CREATED':
            return Object.assign({}, state, {ToDos: action.myNewToDo});
        case 'TODO-REMOVED':
            return Object.assign({}, state, {ToDos: action.updatedToDo});
        case 'EMPLOYEE-CREATED':
            return Object.assign({}, state, {Employees: action.myNewEmployee});
        case 'EMPLOYEE-REMOVED':
            return Object.assign({}, state, {Employees: action.updatedEmployee});
        case 'EMPLOYEE-EXTERNAL':
            return Object.assign({}, state, {ExtEmployees: action.extenalEmployees});
    }
    return state;
}
