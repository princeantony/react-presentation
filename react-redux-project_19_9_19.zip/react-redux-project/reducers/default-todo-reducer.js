
export default function () {
    return [
        {
            id: 1,
            task: 'Build and Release'
        },
        {
            id: 2,
            task: 'Team meeting'    
        }  
    ]
}
