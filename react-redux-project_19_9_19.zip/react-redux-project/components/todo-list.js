import React, {Component} from 'react';
import ReactDOM from 'react-dom';
class TodoList extends Component {
  render() {
    const {toDoItems} = this.props;
    return (
      <ul>
        {toDoItems.map(item => (
          <li key={item.id}>{item.task}</li>
        ))}
      </ul>
    );
  }
}
export default TodoList;