import React, {Component} from 'react';
import ReactDOM from 'react-dom';
class EmployeeList extends Component {
  render() {
    const {employees} = this.props;
    return (
      <table><tbody>
        {employees.map(employee => (
          <tr key={employee.id}>
              <td>{employee.empFname}</td>
              <td>{employee.empLname}</td>
              <td>{employee.empPhone}</td>
              <td>{employee.empEmail}</td>
            </tr>
        ))}
      </tbody></table>
    );
  }
}
export default EmployeeList;