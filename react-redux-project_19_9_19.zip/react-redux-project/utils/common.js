export let isValid=(inputText)=>{
    return inputText != "" ? true : false;
}