export const EMPLOYEE_CONSTANT=
{
    FIRST_NAME: 'Employee First Name: ',
    LAST_NAME:'Employee Last Name: ',
    PHONE_NUMBER:'Phone Number:',
    EMAIL:'Email Address:'

};
export const SERVICE_URL=
{
    GET_EXT_EMPLOYEES_URL: 'https://jsonplaceholder.typicode.com/users'
};
export const MESSAGES=
{
    SERVICE_ERROR: 'There is an error occurred while calling the service!',
    SERVICE_SUCCESS: 'Service call succeeded!',
    SERVICE_START: 'Please wait... Service call in progress!'
};