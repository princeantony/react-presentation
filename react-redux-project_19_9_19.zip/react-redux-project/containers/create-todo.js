import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {saveTodos, removeTodos} from '../actions/todo-action'
import TodoList from '../components/todo-list';
import {isValid} from '../utils/common';
import _ from "lodash";

class CreateToDo extends Component {
  constructor(props) {
    super(props);
    this.state = {items: []};
  }
  createTODO(e) {
    e.preventDefault();
    const _todo = this.refs.txtTodo.value;
    if(isValid(_todo))
    {
      var newItem = {
        task: this.refs.txtTodo.value,
        id: Date.now()
      };
      this.setState((prevState) => ({
        items: prevState.items.concat(newItem)
      }));
      this.refs.txtTodo.value = '';
    }
  }
   // A component life cycle event - 
   // it will be called each time the component load (will not call each render occured by setState)
  componentWillMount() {
       this.setState({items: this.props.existingTodos})
   }
  saveToReducer(e)
  {
    e.preventDefault();
    this.props.actions.saveTodos(this.state.items);
  }
  removeTODO(e)
  {
    e.preventDefault();
    const updatedTodo = _.slice(this.state.items, 0, this.state.items.length - 1);
    this.setState({items: updatedTodo})   
  }
   removeFromReducer(e)
  {
    e.preventDefault();
    const updatedTodo = _.slice(this.state.items, 0, this.state.items.length - 1);
    this.setState({items: updatedTodo})   
    this.props.actions.removeTodos(updatedTodo);
  }
  render() {
    return (
      <div className="new-todo">
        <h3>TODO Component</h3>
        <TodoList toDoItems={this.state.items} />
        <form onSubmit = {this.createTODO.bind(this)} >
            <input  ref="txtTodo" type="text" />
            <button onClick={this.createTODO.bind(this)}>Add to Local State </button>
            <button onClick={this.removeTODO.bind(this)}>Remove from Local State </button>
            <br/><br/>
            <button onClick={this.saveToReducer.bind(this)}>Save to Reduncer</button>
            <button onClick={this.removeFromReducer.bind(this)}>Remove from Reducer</button>
        </form>
      </div>
    );
  }


}
function mapStateToProps(state) {
    return {
     existingTodos: ((state.companyInfo != null && state.companyInfo.ToDos != null ) ? state.companyInfo.ToDos : [] )
    };
}

function matchDispatchToProps(dispatch){
    return {actions : bindActionCreators({saveTodos, removeTodos}, dispatch)};
}

export default connect(mapStateToProps, matchDispatchToProps)(CreateToDo);