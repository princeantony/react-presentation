import React, {Component, PropTypes} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {getExternalEmployee} from '../actions/employee-action';
import ExtEmployeeList from '../components/external-emp-list';
import {isValid} from '../utils/common';
import {MESSAGES} from '../constants/app-constants';
import _ from "lodash";

class ExternalEmployee extends Component {
  constructor(props) {
    super(props);
    this.state = {outSideEmp: [], serviceStatus: ''};
  }
   // A component life cycle event - it will be called each time the component load 
   //(will not call each render occured by setState)
  componentWillMount() {
       this.setState({outSideEmp: this.props.extenalEmployees})
   }

  // A component life cycle event - it will be called each time the component will get new props 
componentWillReceiveProps(newProps) {  
       this.setState({outSideEmp: newProps.extenalEmployees});  
   }
 
  //external service call to Action
  fetchExternalEmployee(e)
  {
    e.preventDefault();
    this.setState({serviceStatus: MESSAGES.SERVICE_START})
     this.props.actions.getExternalEmployee().then(()=> {
           this.setState({serviceStatus: MESSAGES.SERVICE_SUCCESS})
        }).catch(error=> {
            console.log("Error detail ", error);
            this.setState({serviceStatus: MESSAGES.SERVICE_ERROR})
        });
  }
 
  render() {
    return (
      <div className="ext-employee">
        <h3>External Employee Component</h3>
        <div>{this.state.serviceStatus}</div><br />
       <button onClick={this.fetchExternalEmployee.bind(this)}>Get External Employees from service</button>
       <ExtEmployeeList employees={this.state.outSideEmp} /><br/>
      </div>
    );
  }


}

function mapStateToProps(state) {
    return {
       extenalEmployees: ((state.companyInfo != null && state.companyInfo.ExtEmployees != null ) ? state.companyInfo.ExtEmployees : [] )
    };
}

function matchDispatchToProps(dispatch){
  return {actions : bindActionCreators({getExternalEmployee}, dispatch)};
}

export default connect(mapStateToProps, matchDispatchToProps)(ExternalEmployee);