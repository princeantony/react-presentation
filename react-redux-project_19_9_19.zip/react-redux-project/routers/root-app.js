import React, {Component} from 'react';
import { Router, Route,  hashHistory, IndexRoute  } from 'react-router'
import ShowAll from '../containers/showall'
import MainApp from '../containers/main-app'
import CreateToDo from '../containers/create-todo'
import CreateEmployee from '../containers/create-employee'
import ExternalEmployee from '../containers/external-employee'

export default class RootApp extends Component
{
   render()
   { 
      return( <Router history = {hashHistory}>
                <Route path = "/" component = {MainApp}>
                <IndexRoute component = {CreateToDo} />
                <Route path = "home" component = {CreateToDo} />
                <Route path = "emp" component = {CreateEmployee} />
                <Route path = "ext" component = {ExternalEmployee} />
                <Route path = "all" component = {ShowAll} />
            </Route>
        </Router>)
   }
}